# Pacman
This is a simple project for implementing several features that solves the given Artificial Intelligent (AI) problems. There are two subsections 1) search and 2) multiagents.
